# GeoQ — 지도로 배우는 지리 퀴즈

## Firebase Studio에서 실행하기

### 1. 프로젝트 열기
Firebase Studio(studio.firebase.google.com)에서 이 폴더를 엽니다.

### 2. 터미널에서 미리보기
```bash
cd public
npx serve . -p 5000
```
또는 Firebase Studio 우측 패널 → **Preview** 버튼 클릭

### 3. Firebase Hosting 배포

```bash
# Firebase CLI 설치 (최초 1회)
npm install -g firebase-tools

# 로그인
firebase login

# .firebaserc에서 프로젝트 ID 설정
# "YOUR_PROJECT_ID" → 본인 Firebase 프로젝트 ID로 변경

# 배포
firebase deploy --only hosting
```

## 폴더 구조
```
public/
├── index.html       ← 홈
├── quiz.html        ← 게임 (Level 1/2/3 통합)
├── result.html      ← 결과
├── css/style.css    ← 전체 디자인 시스템
├── js/
│   ├── i18n.js      ← 한/영 다국어
│   └── engine.js    ← 게임 엔진
├── data/            ← 퀴즈 JSON
├── maps/            ← SVG 지도
└── locales/         ← 번역 파일
```

## 게임 레벨
| 레벨 | 방식 | 특징 |
|------|------|------|
| LV.1 | 4지선다 | 힌트 자유, 시간 제한 없음 |
| LV.2 | 8지선다 | 힌트 시 0.5점, 15초 타이머 |
| LV.3 | 지도 클릭 | 지역명 보고 직접 지도에서 찾기 |

## 새 지도 추가
1. `public/maps/` 에 SVG 파일 추가
2. `public/data/quiz-{id}.json` 생성
3. `public/locales/ko.json`, `en.json` 에 지도 이름 추가
4. `index.html` 의 지도 카드에 추가
